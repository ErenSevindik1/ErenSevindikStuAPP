package Models;

import javax.swing.*;

public class Ogrenci {
    public String OgrenciAdi;
    public String OgrenciSoyadi;
    public String OgrenciNo;
    public  String DersGoster;
    public String OgrenciDers;


}