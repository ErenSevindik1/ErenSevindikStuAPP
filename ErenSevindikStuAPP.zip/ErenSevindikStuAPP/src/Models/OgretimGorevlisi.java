package Models;

public class OgretimGorevlisi {
   public String OgretmenNo;
    public String Ad;
    public String Soyad;
    public String Bolum;


}
